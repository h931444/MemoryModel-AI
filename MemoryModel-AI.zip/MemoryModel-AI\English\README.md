# MemoryModel-AI · Memory Model v2 (Make any AI run this logic automatically)

> An open-source **system-prompt** project that lets any LLM run "Memory Model v2" automatically.
> The core is a rules file you can paste straight into an AI's system prompt. No coding, no network, no permissions needed.

---

## What this is

Not a program — a **set of prompt rules**. Put the content of `system_prompt.md` into your AI's "system prompt / personality / custom instructions", and the AI will **automatically** across turns:
- Identify and classify your stable traits (personality / habits / hobbies / skills / environment)
- Archive, refine, forget, and resolve conflicts
- Answer in a personalized way using that memory

### Supported platforms (pick any)
| Platform | Where to put it |
|---|---|
| Doubao | Create a "custom agent / persona" and paste the rules |
| ChatGPT | Settings → Custom instructions |
| Claude | Project → Custom instructions |
| Local models (Ollama, etc.) | system prompt parameter |
| Open-source bots | the bot's system prompt config |

### Why a prompt instead of a program
- **Cross-platform**: any AI that allows custom instructions can load it
- No Python, no admin rights, no internet needed
- Memory is done automatically inside the conversation — zero manual work for the user

---

## Project structure
```
MemoryModel-AI/
├── README.md                 # this root index
├── 中文版/                     # Chinese version
│   ├── README.md
│   └── system_prompt.md       # ★ core rules (Chinese)
└── English/                   # English version
    ├── README.md
    └── system_prompt.md       # ★ core rules (English)
```

---

## How to use
1. Open `system_prompt.md` in the language folder you want, and copy it all.
2. Paste it into your AI's "system prompt / persona / custom instructions".
3. Start talking. The AI will run the four-layer memory logic:
   - Perception: decide whether to go online
   - Interpretation: classify your words into traits
   - Memory: archive, refine, forget, handle conflicts
   - Generation: answer in a personalized way

---

## Memory Model v2 design (overview)
```
input → perception(online-check) → interpretation(classification)
      → memory(3-layer storage: short-term/dialogue library/long-term preferences; refine; forget; conflict)
      → generation(personalized output)
```

### Key mechanisms
| Mechanism | Default |
|---|---|
| Refinement evidence cap | 50 sentences (configurable; ask before refining) |
| Memory strength decay | 30 days |
| Archive trigger | earliest dialogue beyond half the context, or user manual |
| Conflict handling | ask / mark pending; never silently overwrite |
| Privacy boundary | never record passwords/IDs/sensitive info |

Details in `system_prompt.md`.

---

## License
MIT License — free to use, modify, and distribute.
